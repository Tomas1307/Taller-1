import { Course } from './course.js';

export const dataCourses = [
  new Course("Ingeniería de Sw", "Pablo Picasso", 4),
  new Course("Futbol 1", "Freddy Rincón", 2),
  new Course("Algoritmos", "Carlos Fuentes", 2),
  new Course("Estructuras de Datos", "Yesid D", 1),
  new Course("Futbol 2", "James R", 6)
] 