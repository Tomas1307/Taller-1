export class Student {
    name: string
    codigo: number;
    cedula: number;
    edad: number;
    direccion: string;
    telefono:number;

    student(name:string, codigo: number,cedula: number,edad: number,direccion: string,telefono:number){
        this.name= name;
        this.codigo =codigo;
        this.cedula=cedula
        this.edad= edad;
        this.direccion= direccion;
        this.telefono = telefono;
    }
}