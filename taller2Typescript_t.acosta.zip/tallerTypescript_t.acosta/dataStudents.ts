import { Student } from './student.js';
const est1 = new Student()
est1.name = "Tomas Acosta Bernal"
est1.codigo = 202011237
est1.cedula = 1001091261
est1.edad = 19
est1.direccion = "Calle 160 # 73"
est1.telefono = 3138531548

const est2 = new Student()
est1.name = "Camila Rodriguez Cortazar"
est1.codigo = 202011215
est1.cedula = 1001091261
est1.edad = 19
est1.direccion = "Calle 21A #3"
est1.telefono = 3143520320

const est3 = new Student()
est1.name = "Manuel"
est1.codigo = 202013256
est1.cedula = 10008546951
est1.edad = 20
est1.direccion = "Calle 147# 26"
est1.telefono = 3111448256

export const dataStudents = [est1,est2,est3] 