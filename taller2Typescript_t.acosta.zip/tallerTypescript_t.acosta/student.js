"use strict";
exports.__esModule = true;
exports.Student = void 0;
var Student = /** @class */ (function () {
    function Student() {
    }
    Student.prototype.student = function (name, codigo, cedula, edad, direccion, telefono) {
        this.name = name;
        this.codigo = codigo;
        this.cedula = cedula;
        this.edad = edad;
        this.direccion = direccion;
        this.telefono = telefono;
    };
    return Student;
}());
exports.Student = Student;
