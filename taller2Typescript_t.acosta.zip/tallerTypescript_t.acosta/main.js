"use strict";
exports.__esModule = true;
var coursesTbody = document.getElementById('courses'); // Nodo tbody que tiene el id="courses"
function renderCoursesInTable(courses) {
    courses.forEach(function (c) {
        var trElement = document.createElement("tr");
        trElement.innerHTML = "<td>" + c.name + "</td>\n                           <td>" + c.professor + "</td>\n                           <td>" + c.credits + "</td>";
        coursesTbody.appendChild(trElement);
    });
    function getTotalCredits(courses) {
        var totalCredits = 0;
        courses.forEach(function (course) { return totalCredits = totalCredits + course.credits; });
        return totalCredits;
    }
}
